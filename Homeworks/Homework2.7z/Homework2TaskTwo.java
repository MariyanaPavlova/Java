public class Homework2TaskTwo {
    public static void main(String[] args){
        for (int i = -20; i <= 50; i++){
            System.out.println(i+ " ");
        }
    }
}
