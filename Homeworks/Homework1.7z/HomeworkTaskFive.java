import java.util.Scanner;

public class HomeworkTaskFive {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        double a = sc.nextDouble();
        double b = sc.nextDouble();
        double c = sc.nextDouble();
        a--;
        b--;
        c--;
        System.out.println("a = " + a);
        System.out.println("b = " + b);
        System.out.println("b = " + c);
    }
}
