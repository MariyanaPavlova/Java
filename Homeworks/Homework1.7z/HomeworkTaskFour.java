import java.util.Scanner;


public class HomeworkTaskFour {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        double a = sc.nextDouble();
        double b = sc.nextDouble();
        a++;
        a++;
        b++;
        b++;
        System.out.println("a = " + a);
        System.out.println("b = " + b);
    }
}
