package lesson09.homework8;

public class UserImpl extends AbstractUser{

    public UserImpl(String username){
        super(username);
    }

}
